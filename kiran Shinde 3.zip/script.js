

let boardState = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let gameActive = false;
let vsAI = false;

let scoreX = 0;
let scoreO = 0;
let drawCount = 0;

const statusDisplay = document.getElementById("status");
const cells = document.querySelectorAll(".cell");
const resetBtn = document.getElementById("resetBtn");
const pvpBtn = document.getElementById("pvpBtn");
const aiBtn = document.getElementById("aiBtn");

const scoreXEl = document.getElementById("scoreX");
const scoreOEl = document.getElementById("scoreO");
const drawsEl = document.getElementById("draws");

const winningConditions = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
];

function startGame(modeAI) {
    vsAI = modeAI;
    gameActive = true;
    boardState = ["", "", "", "", "", "", "", "", ""];
    currentPlayer = "X";
    statusDisplay.textContent = "Player X's Turn";
    cells.forEach(cell => cell.textContent = "");
}

function handleCellClick(event) {
    const index = event.target.getAttribute("data-index");

    if (boardState[index] !== "" || !gameActive) return;

    makeMove(index, currentPlayer);

    if (checkResult()) return;

    switchPlayer();

    if (vsAI && currentPlayer === "O") {
        setTimeout(aiMove, 500);
    }
}

function makeMove(index, player) {
    boardState[index] = player;
    cells[index].textContent = player;
}

function switchPlayer() {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusDisplay.textContent = "Player " + currentPlayer + "'s Turn";
}

function checkResult() {
    let roundWon = false;

    for (let condition of winningConditions) {
        const [a, b, c] = condition;
        if (boardState[a] && boardState[a] === boardState[b] && boardState[a] === boardState[c]) {
            roundWon = true;
            break;
        }
    }

    if (roundWon) {
        statusDisplay.textContent = "Player " + currentPlayer + " Wins!";
        if (currentPlayer === "X") scoreX++;
        else scoreO++;
        updateScore();
        gameActive = false;
        return true;
    }

    if (!boardState.includes("")) {
        statusDisplay.textContent = "Game Draw!";
        drawCount++;
        updateScore();
        gameActive = false;
        return true;
    }

    return false;
}

function updateScore() {
    scoreXEl.textContent = scoreX;
    scoreOEl.textContent = scoreO;
    drawsEl.textContent = drawCount;
}

function resetGame() {
    boardState = ["", "", "", "", "", "", "", "", ""];
    gameActive = true;
    currentPlayer = "X";
    statusDisplay.textContent = "Player X's Turn";
    cells.forEach(cell => cell.textContent = "");
}

function aiMove() {
    let available = boardState.map((val, idx) => val === "" ? idx : null).filter(v => v !== null);
    if (available.length === 0) return;

    let randomIndex = available[Math.floor(Math.random() * available.length)];
    makeMove(randomIndex, "O");

    if (checkResult()) return;

    switchPlayer();
}

cells.forEach(cell => cell.addEventListener("click", handleCellClick));
resetBtn.addEventListener("click", resetGame);
pvpBtn.addEventListener("click", () => startGame(false));
aiBtn.addEventListener("click", () => startGame(true));

